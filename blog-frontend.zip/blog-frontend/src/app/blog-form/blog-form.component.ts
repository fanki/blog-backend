import { Component } from '@angular/core';
import { BlogService } from '../blog.service';

@Component({
  selector: 'app-blog-form',
  templateUrl: './blog-form.component.html',
})
export class BlogFormComponent {
  title = '';
  content = '';

  constructor(private blogService: BlogService) {}

  createPost(): void {
    const newBlog = { title: this.title, content: this.content };
    this.blogService.createBlog(newBlog).subscribe(() => {
      alert('Blog erfolgreich erstellt!');
      this.title = '';
      this.content = '';
    });
  }
}